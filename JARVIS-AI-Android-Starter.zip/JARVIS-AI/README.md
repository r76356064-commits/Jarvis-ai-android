# JARVIS AI Android Starter

This is a starter Android app, not a finished unrestricted AI assistant.

## Included now
- Bangla speech recognition through Android's available speech service
- Bangla text-to-speech (device voice availability varies)
- Local command examples: flashlight, battery, time, YouTube launch, Settings, volume
- Dark blue JARVIS-inspired Compose interface
- GitHub Actions workflow to build a debug APK

## Build on GitHub
1. Create a private GitHub repository.
2. Upload the CONTENTS of this ZIP (not the ZIP file itself).
3. Commit to the `main` branch.
4. Open Actions and select `Build JARVIS APK`, then `Run workflow`.
5. Download the `JARVIS-debug-APK` artifact from the completed run.

The workflow uses Gradle 8.9 and JDK 17. GitHub Actions will download the Android Gradle Plugin and Android SDK dependencies during the build.

## Important limitations
- This starter does not yet connect to a hosted AI model. The chat screen currently runs local demo commands.
- Speech recognition generally requires an Android speech service and may use internet.
- Flashlight access requires camera permission.
- Android restrictions prevent unrestricted background listening and arbitrary control of all apps/settings.
- Do not put AI API keys in the Android app. Add a secured backend before connecting an AI model.
- This source has not been compiled on a physical device in this environment. Treat the GitHub Actions build as the compile check.
