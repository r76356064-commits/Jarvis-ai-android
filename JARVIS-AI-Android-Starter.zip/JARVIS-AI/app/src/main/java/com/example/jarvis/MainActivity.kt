package com.example.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var listeningCallback: ((String) -> Unit)? = null
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListeningInternal()
        else listeningCallback?.invoke("মাইক্রোফোন ব্যবহারের অনুমতি দেওয়া হয়নি।")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { JarvisScreen(
            onSpeak = { speak(it) },
            onListen = { callback ->
                listeningCallback = callback
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    startListeningInternal()
                } else requestMic.launch(Manifest.permission.RECORD_AUDIO)
            },
            onCommand = { command -> handleCommand(command) }
        ) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startListeningInternal() {
        val recognizer = speechRecognizer ?: run {
            listeningCallback?.invoke("এই ফোনে Speech Recognition সুবিধা পাওয়া যাচ্ছে না।")
            return
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { listeningCallback?.invoke("কথা বুঝতে পারিনি। আবার চেষ্টা করো।") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                listeningCallback?.invoke(text.ifBlank { "কোনো কথা শনাক্ত হয়নি।" })
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS-কে নির্দেশ দিন")
        }
        recognizer.startListening(intent)
    }

    private fun handleCommand(raw: String): String {
        val c = raw.lowercase(Locale.ROOT)
        return when {
            c.contains("flash") || c.contains("ফ্ল্যাশ") || c.contains("টর্চ") || c.contains("লাইট") -> {
                setFlashlight(true); "ফ্ল্যাশলাইট চালু করার চেষ্টা করেছি।"
            }
            c.contains("battery") || c.contains("ব্যাটারি") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                "তোমার ফোনের ব্যাটারি ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} শতাংশ।"
            }
            c.contains("time") || c.contains("সময়") || c.contains("সময়") -> {
                "এখন সময় ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())}।"
            }
            c.contains("youtube") -> { openApp("com.google.android.youtube"); "ইউটিউব খোলার চেষ্টা করছি।" }
            c.contains("settings") || c.contains("সেটিংস") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "সেটিংস খুলছি।"
            }
            c.contains("volume") || c.contains("ভলিউম") || c.contains("শব্দ") -> {
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "ভলিউম বাড়ানোর চেষ্টা করেছি।"
            }
            else -> "আমি তোমার কথা শুনেছি: $raw। এই সংস্করণে এই নির্দেশটি এখনো যোগ করা হয়নি।"
        }
    }

    private fun openApp(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let { startActivity(it) }
    }

    private fun setFlashlight(enabled: Boolean) {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId != null && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                manager.setTorchMode(cameraId, enabled)
            } else if (cameraId != null) {
                requestCamera.launch(Manifest.permission.CAMERA)
            }
        } catch (_: Exception) { }
    }

    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) setFlashlight(true)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(
    onSpeak: (String) -> Unit,
    onListen: (((String) -> Unit)) -> Unit,
    onCommand: (String) -> String
) {
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("SYSTEM ONLINE") }
    val messages = remember { mutableStateListOf("JARVIS: স্বাগতম। আমি JARVIS, তোমার সহকারী।") }
    val bg = Brush.verticalGradient(listOf(Color(0xFF061526), Color(0xFF020711), Color(0xFF071D31)))
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF39C8FF), secondary = Color(0xFF00AEEF),
        background = Color(0xFF020711), surface = Color(0xFF0B2034)
    )) {
        Column(Modifier.fillMaxSize().background(bg).padding(18.dp)) {
            Text("J.A.R.V.I.S", color = Color(0xFF55D8FF), fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("PERSONAL AI ASSISTANT  •  $status", color = Color(0xFF83BFD8), fontSize = 10.sp)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(170.dp).background(Color(0x2239C8FF), CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(132.dp).background(Color(0x3339C8FF), CircleShape), contentAlignment = Alignment.Center) {
                        Text("J", color = Color(0xFF6CE0FF), fontSize = 76.sp, fontWeight = FontWeight.Light)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("CONVERSATION", color = Color(0xFF55D8FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp)) {
                items(messages) { msg ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xAA102B43)),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text(msg, Modifier.padding(12.dp), color = Color(0xFFE2F7FF), fontSize = 14.sp) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("JARVIS-কে কিছু বলো…", color = Color.Gray) },
                    singleLine = true
                )
                IconButton(onClick = {
                    onListen { heard ->
                        if (heard.isNotBlank()) {
                            messages.add("তুমি: $heard")
                            val reply = onCommand(heard)
                            messages.add("JARVIS: $reply")
                            onSpeak(reply)
                        }
                    }
                }) { Icon(Icons.Default.Mic, contentDescription = "Voice", tint = Color(0xFF55D8FF)) }
                IconButton(onClick = {
                    if (input.isNotBlank()) {
                        val cmd = input
                        messages.add("তুমি: $cmd")
                        val reply = onCommand(cmd)
                        messages.add("JARVIS: $reply")
                        onSpeak(reply)
                        input = ""
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF55D8FF)) }
            }
            Spacer(Modifier.height(8.dp))
            Text("VOICE • DEVICE COMMANDS • LOCAL DEMO", color = Color(0xFF54849C), fontSize = 9.sp)
        }
    }
}
